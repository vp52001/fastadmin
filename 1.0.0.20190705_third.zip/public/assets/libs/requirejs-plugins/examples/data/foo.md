# This content was loaded from a markdown file!

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

## It is very useful for content-heavy sites

Ut enim ad minim veniam, quis nostrud *exercitation* ullamco laboris nisi ut
aliquip ex ea commodo consequat. Duis aute irure **dolor in reprehenderit** in
voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
occaecat cupidatat non proident, sunt in culpa qui officia `deserunt` mollit
anim id est laborum.

### You can change the markdownConverter if needed

 - the markdownConverter is kept as a separate file:
    - if you project already uses one you can simply reuse it.
    - so plugin is more flexible.
 - this plugin is not targeted to dynamic loading after build:
    - check plugin source code for more info.

